// src/context/DataContext.js
import React, { createContext, useContext, useState } from 'react';

const DataContext = createContext();

export const DataProvider = ({ children }) => {
  const [wishlist, setWishlist] = useState([]);
  const [myTrips, setMyTrips] = useState([]);

  // Wishlist functions
  const addToWishlist = (destination) => {
    if (wishlist.find(item => item.id === destination.id)) {
      return;
    }
    const updatedWishlist = [...wishlist, { ...destination, addedAt: new Date() }];
    setWishlist(updatedWishlist);
  };

  const removeFromWishlist = (id) => {
    const updatedWishlist = wishlist.filter(item => item.id !== id);
    setWishlist(updatedWishlist);
  };

  const toggleWishlist = (destination) => {
    const isInWishlist = wishlist.find(item => item.id === destination.id);
    if (isInWishlist) {
      removeFromWishlist(destination.id);
    } else {
      addToWishlist(destination);
    }
  };

  const isInWishlist = (id) => {
    return wishlist.some(item => item.id === id);
  };

  // MyTrips functions
  const addToMyTrips = (destination) => {
    if (myTrips.find(item => item.id === destination.id)) {
      return;
    }

    const newTrip = {
      ...destination,
      bookingId: `SP-${new Date().getFullYear()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      bookingDate: new Date().toISOString(),
      status: 'Confirmed',
      travelers: 1,
      date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric' 
      }),
    };

    const updatedTrips = [...myTrips, newTrip];
    setMyTrips(updatedTrips);
  };
  const updateTripStatus = (tripId, newStatus) => {
  const updatedTrips = myTrips.map(trip => 
    trip.id === tripId ? { ...trip, status: newStatus } : trip
  );
  setMyTrips(updatedTrips);
};
  const removeFromMyTrips = (id) => {
    const updatedTrips = myTrips.filter(item => item.id !== id);
    setMyTrips(updatedTrips);
  };

  const isInMyTrips = (id) => {
    return myTrips.some(item => item.id === id);
  };

  const value = {
    wishlist,
    setWishlist,
    myTrips,
    setMyTrips,
    addToWishlist,
    removeFromWishlist,
    toggleWishlist,
    isInWishlist,
    addToMyTrips,
    removeFromMyTrips,
    isInMyTrips,
      updateTripStatus,
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};