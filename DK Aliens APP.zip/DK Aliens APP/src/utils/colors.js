// Enhanced Black/Blue Space-themed color palette
export const COLORS = {
  // Primary Colors - Blue theme
  primary: '#2563EB',        // Electric blue
  primaryLight: '#3B82F6',
  primaryDark: '#1D4ED8',
  
  // Accent Colors - Cyan/Blue accents
  accent: '#06B6D4',         // Electric cyan
  accentLight: '#22D3EE',
  accentDark: '#0891B2',
  
  // Secondary Accents
  secondary: '#8B5CF6',      // Purple accent
  tertiary: '#10B981',       // Green accent
  
  // Background Colors - Dark theme
  background: '#0A0F1C',     // Deep space dark
  backgroundLight: '#111827', // Slightly lighter dark
  cardBg: '#1E293B',         // Card background
  cardBgLight: '#334155',    // Lighter card variant
  
  // Text Colors
  text: '#F8FAFC',
  textSecondary: '#CBD5E1',
  textTertiary: '#94A3B8',
  textDark: '#1E293B',
  
  // Status Colors
  success: '#10B981',
  successLight: '#34D399',
  warning: '#F59E0B',
  warningLight: '#FBBF24',
  error: '#EF4444',
  errorLight: '#F87171',
  
  // Neutral Colors
  white: '#FFFFFF',
  black: '#000000',
  gray: '#64748B',
  lightGray: '#E2E8F0',
  darkGray: '#475569',
  
  // Star/Rating Color
  star: '#FBBF24',
  starLight: '#FCD34D',
  
  // Gradient Colors
  gradientStart: '#0F172A',
  gradientMid: '#1E293B',
  gradientEnd: '#0A0F1C',
  
  // Special Effects
  glow: 'rgba(37, 99, 235, 0.3)',
  nebula: 'rgba(59, 130, 246, 0.1)',
};

export default COLORS;