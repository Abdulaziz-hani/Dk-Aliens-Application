import React, { useState } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import BottomTabNavigator from './BottomTabNavigator';
import DestinationDetailsScreen from '../screens/DestinationDetailsScreen';
import TripDetailsScreen from '../screens/TripDetailsScreen';
import AboutUsScreen from '../screens/AboutUsScreen';

const Stack = createNativeStackNavigator();

const AppNavigator = () => {
  const [globalWishlist, setGlobalWishlist] = useState([]);
  const [globalMyTrips, setGlobalMyTrips] = useState([]);

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MainTabs">
        {() => (
          <BottomTabNavigator 
            globalWishlist={globalWishlist}
            setGlobalWishlist={setGlobalWishlist}
            globalMyTrips={globalMyTrips}
            setGlobalMyTrips={setGlobalMyTrips}
          />
        )}
      </Stack.Screen>
      <Stack.Screen name="DestinationDetails">
        {(props) => (
          <DestinationDetailsScreen 
            {...props}
            globalWishlist={globalWishlist}
            setGlobalWishlist={setGlobalWishlist}
            globalMyTrips={globalMyTrips}
            setGlobalMyTrips={setGlobalMyTrips}
          />
        )}
      </Stack.Screen>
      <Stack.Screen name="TripDetails" component={TripDetailsScreen} />
      <Stack.Screen 
        name="AboutUs" 
        component={AboutUsScreen}
        options={{ 
          headerShown: true,
          headerTitle: 'About Us',
          headerStyle: {
            backgroundColor: '#1A1F3A',
          },
          headerTintColor: '#FFFFFF',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
    </Stack.Navigator>
  );
};

export default AppNavigator;