import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';

const TripDetailsScreen = ({ navigation, route }) => {
  const { trip } = route.params;

  const StatusBadge = ({ status }) => {
    const getStatusConfig = () => {
      switch (status) {
        case 'Confirmed':
          return { color: COLORS.success, icon: 'checkmark-circle' };
        case 'Pending Payment':
          return { color: COLORS.warning, icon: 'time' };
        case 'Completed':
          return { color: COLORS.accent, icon: 'rocket' };
        default:
          return { color: COLORS.gray, icon: 'close-circle' };
      }
    };

    const config = getStatusConfig();

    return (
      <View style={[styles.statusBadge, { backgroundColor: config.color + '20' }]}>
        <Ionicons name={config.icon} size={16} color={config.color} />
        <Text style={[styles.statusText, { color: config.color }]}>{status}</Text>
      </View>
    );
  };

  const tripInfo = [
    { icon: 'calendar-outline', label: 'Departure Date', value: trip.date },
    { icon: 'time-outline', label: 'Duration', value: trip.duration },
    { icon: 'people-outline', label: 'Travelers', value: `${trip.travelers} person${trip.travelers > 1 ? 's' : ''}` },
    { icon: 'pricetag-outline', label: 'Booking ID', value: trip.bookingId },
    { icon: 'rocket-outline', label: 'Distance', value: trip.distance },
    { icon: 'location-outline', label: 'Destination', value: trip.name || trip.destination },
  ];

  const downloadTicket = () => {
    console.log('Downloading ticket...');
  };

  const contactSupport = () => {
    console.log('Contacting support...');
  };

  const modifyBooking = () => {
    console.log('Modifying booking...');
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="arrow-back" size={24} color={COLORS.white} />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Trip Details</Text>
            <TouchableOpacity style={styles.shareButton}>
              <Ionicons name="share-outline" size={24} color={COLORS.white} />
            </TouchableOpacity>
          </View>

          {/* Hero Image */}
          <View style={styles.imageSection}>
            <Image source={{ uri: trip.image }} style={styles.tripImage} />
            <LinearGradient
              colors={['transparent', 'rgba(10, 15, 28, 0.8)']}
              style={styles.imageGradient}
            />
            <View style={styles.imageOverlay}>
              <StatusBadge status={trip.status} />
            </View>
          </View>

          {/* Trip Title */}
          <View style={styles.titleSection}>
            <Text style={styles.tripTitle}>{trip.name || trip.destination}</Text>
            <View style={styles.priceTag}>
              <Text style={styles.priceLabel}>Total Paid</Text>
              <Text style={styles.priceValue}>${(trip.price / 1000).toFixed(0)}K</Text>
            </View>
          </View>

          {/* Trip Information */}
          <View style={styles.infoSection}>
            <Text style={styles.sectionTitle}>Trip Information</Text>
            <LinearGradient
              colors={[COLORS.cardBg, COLORS.cardBgLight]}
              style={styles.infoCard}
            >
              {tripInfo.map((info, index) => (
                <View 
                  key={index} 
                  style={[
                    styles.infoItem,
                    index !== tripInfo.length - 1 && styles.infoItemBorder
                  ]}
                >
                  <View style={styles.infoLeft}>
                    <View style={styles.infoIcon}>
                      <Ionicons name={info.icon} size={20} color={COLORS.primary} />
                    </View>
                    <Text style={styles.infoLabel}>{info.label}</Text>
                  </View>
                  <Text style={styles.infoValue}>{info.value}</Text>
                </View>
              ))}
            </LinearGradient>
          </View>

          {/* Important Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Important Information</Text>
            <LinearGradient
              colors={[COLORS.cardBg, COLORS.cardBgLight]}
              style={styles.alertCard}
            >
              <View style={styles.alertItem}>
                <Ionicons name="information-circle" size={20} color={COLORS.accent} />
                <Text style={styles.alertText}>
                  Please arrive at the spaceport 4 hours before departure
                </Text>
              </View>
              <View style={styles.alertItem}>
                <Ionicons name="warning" size={20} color={COLORS.warning} />
                <Text style={styles.alertText}>
                  Ensure all travel documents are valid and up to date
                </Text>
              </View>
              <View style={styles.alertItem}>
                <Ionicons name="shield-checkmark" size={20} color={COLORS.success} />
                <Text style={styles.alertText}>
                  Travel insurance is included in your booking
                </Text>
              </View>
            </LinearGradient>
          </View>

          {/* What's Included */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>What's Included</Text>
            <LinearGradient
              colors={[COLORS.cardBg, COLORS.cardBgLight]}
              style={styles.includedCard}
            >
              {[
                'Round-trip space travel',
                'Accommodation on space station',
                'All meals and refreshments',
                'Professional astronaut guides',
                'Safety equipment and training',
                'Zero-gravity experiences',
              ].map((item, index) => (
                <View key={index} style={styles.includedItem}>
                  <Ionicons name="checkmark-circle" size={18} color={COLORS.success} />
                  <Text style={styles.includedText}>{item}</Text>
                </View>
              ))}
            </LinearGradient>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionsSection}>
            <TouchableOpacity 
              style={styles.primaryActionButton}
              onPress={downloadTicket}
            >
              <Ionicons name="download-outline" size={20} color={COLORS.white} />
              <Text style={styles.primaryActionText}>Download Ticket</Text>
            </TouchableOpacity>

            <View style={styles.secondaryActions}>
              <TouchableOpacity 
                style={styles.secondaryActionButton}
                onPress={modifyBooking}
              >
                <Ionicons name="create-outline" size={20} color={COLORS.primary} />
                <Text style={styles.secondaryActionText}>Modify</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.secondaryActionButton}
                onPress={contactSupport}
              >
                <Ionicons name="chatbubbles-outline" size={20} color={COLORS.primary} />
                <Text style={styles.secondaryActionText}>Support</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Contact Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Need Help?</Text>
            <LinearGradient
              colors={[COLORS.cardBg, COLORS.cardBgLight]}
              style={styles.contactCard}
            >
              <Text style={styles.contactText}>
                For any questions or concerns about your trip, our support team is available 24/7
              </Text>
              <TouchableOpacity style={styles.contactButton}>
                <Ionicons name="call" size={18} color={COLORS.white} />
                <Text style={styles.contactButtonText}>+1 (800) SPACE-TRAVEL</Text>
              </TouchableOpacity>
            </LinearGradient>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 20,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  shareButton: {
    padding: 8,
  },
  imageSection: {
    position: 'relative',
    height: 250,
    marginHorizontal: 24,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 24,
  },
  tripImage: {
    width: '100%',
    height: '100%',
  },
  imageGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
  },
  imageOverlay: {
    position: 'absolute',
    top: 16,
    right: 16,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    gap: 6,
  },
  statusText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  titleSection: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  tripTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 12,
    fontFamily: 'System',
  },
  priceTag: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  priceLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginRight: 8,
  },
  priceValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.accent,
    fontFamily: 'System',
  },
  infoSection: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 16,
    fontFamily: 'System',
  },
  infoCard: {
    borderRadius: 20,
    padding: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  infoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  infoItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primaryDark,
  },
  infoLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  infoIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: COLORS.primary + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  infoLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  section: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  alertCard: {
    borderRadius: 20,
    padding: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  alertText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginLeft: 12,
    flex: 1,
    lineHeight: 20,
  },
  includedCard: {
    borderRadius: 20,
    padding: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  includedItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  includedText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginLeft: 12,
  },
  actionsSection: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  primaryActionButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  primaryActionText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  secondaryActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  secondaryActionButton: {
    flex: 1,
    backgroundColor: COLORS.cardBg,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: COLORS.primary + '30',
  },
  secondaryActionText: {
    color: COLORS.primary,
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  contactCard: {
    borderRadius: 20,
    padding: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  contactText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  contactButton: {
    backgroundColor: COLORS.success,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
  },
  contactButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 8,
  },
});

export default TripDetailsScreen;