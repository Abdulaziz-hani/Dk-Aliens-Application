import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';
import { destinations, categories } from '../data/destinations';
import { useData } from '../context/DataContext';

const { width } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
  const [selectedCategory, setSelectedCategory] = useState('Planets');
  const [searchQuery, setSearchQuery] = useState('');
  
  const {
    wishlist,
    toggleWishlist,
    addToMyTrips,
    isInWishlist,
    isInMyTrips,
  } = useData();

  const CategoryIcon = ({ name, isActive }) => {
    const iconMap = {
      'Planets': 'planet',
      'Stations': 'rocket',
      'Moons': 'moon',
      'Asteroids': 'star',
      'Special': 'sparkles',
    };
    return (
      <Ionicons 
        name={iconMap[name]} 
        size={24} 
        color={isActive ? COLORS.white : COLORS.textSecondary} 
      />
    );
  };

  const filteredDestinations = destinations.filter(dest =>
    dest.category === selectedCategory.toLowerCase().slice(0, -1) ||
    selectedCategory === 'Special'
  );

  const navigateToWishlist = () => {
    navigation.navigate('Wishlist');
  };

  const navigateToMyTrips = () => {
    navigation.navigate('MyTrips');
  };

  const navigateToExplore = () => {
    navigation.navigate('Explore');
  };

  const navigateToDestinationDetails = (destination) => {
    navigation.navigate('DestinationDetails', {
      destination,
      isInWishlist: isInWishlist(destination.id),
      isInMyTrips: isInMyTrips(destination.id),
    });
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <View>
              <Text style={styles.greeting}>Welcome back,</Text>
              <Text style={styles.userName}>Space Explorer!</Text>
            </View>
            <View style={styles.headerIcons}>
              <TouchableOpacity 
                style={styles.iconButton}
                onPress={navigateToWishlist}
              >
                <Ionicons name="heart" size={24} color={COLORS.white} />
                {wishlist.length > 0 && (
                  <View style={styles.iconBadge}>
                    <Text style={styles.badgeText}>{wishlist.length}</Text>
                  </View>
                )}
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.iconButton}
                onPress={navigateToMyTrips}
              >
                <Ionicons name="rocket" size={24} color={COLORS.white} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Search Bar */}
          <View style={styles.searchSection}>
            <View style={styles.searchContainer}>
              <Ionicons name="search" size={20} color={COLORS.textSecondary} style={styles.searchIcon} />
              <TextInput
                style={styles.searchInput}
                placeholder="Search cosmic destinations..."
                placeholderTextColor={COLORS.textSecondary}
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
              <TouchableOpacity 
                style={styles.filterButton}
                onPress={navigateToExplore}
              >
                <Ionicons name="options-outline" size={20} color={COLORS.white} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Category Tabs */}
          <View style={styles.categorySection}>
            <Text style={styles.sectionTitle}>Explore Categories</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryContainer}>
              {categories.map((category) => {
                const isActive = selectedCategory === category.name;
                return (
                  <TouchableOpacity
                    key={category.id}
                    style={[
                      styles.categoryTab,
                      isActive && styles.categoryTabActive,
                    ]}
                    onPress={() => setSelectedCategory(category.name)}
                  >
                    <LinearGradient
                      colors={isActive ? 
                        [COLORS.primary, COLORS.primaryDark] : 
                        [COLORS.cardBg, COLORS.cardBg]
                      }
                      style={styles.categoryGradient}
                    >
                      <CategoryIcon name={category.name} isActive={isActive} />
                      <Text style={[
                        styles.categoryText,
                        isActive && styles.categoryTextActive
                      ]}>
                        {category.name}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>

          {/* Featured Destinations */}
          <View style={styles.featuredSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Featured Destinations</Text>
              <TouchableOpacity onPress={navigateToExplore}>
                <Text style={styles.seeAllText}>See All</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.featuredScroll}>
              {destinations.slice(0, 3).map((destination) => (
                <TouchableOpacity 
                  key={destination.id} 
                  style={styles.featuredCard}
                  onPress={() => navigateToDestinationDetails(destination)}
                >
                  <Image source={{ uri: destination.image }} style={styles.featuredImage} />
                  <LinearGradient
                    colors={['transparent', 'rgba(10, 15, 28, 0.95)']}
                    style={styles.featuredGradient}
                  >
                    <TouchableOpacity
                      style={styles.wishlistButton}
                      onPress={(e) => {
                        e.stopPropagation();
                        toggleWishlist(destination);
                      }}
                    >
                      <Ionicons
                        name={isInWishlist(destination.id) ? 'heart' : 'heart-outline'}
                        size={24}
                        color={COLORS.accent}
                      />
                    </TouchableOpacity>
                    
                    {destination.isFeatured && (
                      <View style={styles.featuredBadge}>
                        <Text style={styles.featuredBadgeText}>FEATURED</Text>
                      </View>
                    )}
                    
                    <View style={styles.featuredInfo}>
                      <Text style={styles.featuredTitle}>{destination.name}</Text>
                      <Text style={styles.featuredDescription}>{destination.description}</Text>
                      <View style={styles.featuredFooter}>
                        <View style={styles.ratingContainer}>
                          <Ionicons name="star" size={16} color={COLORS.star} />
                          <Text style={styles.ratingText}>{destination.rating}</Text>
                        </View>
                        <TouchableOpacity 
                          style={[
                            styles.cartButton,
                            isInMyTrips(destination.id) && styles.cartButtonAdded
                          ]}
                          onPress={(e) => {
                            e.stopPropagation();
                            if (!isInMyTrips(destination.id)) {
                              addToMyTrips(destination);
                            }
                          }}
                        >
                          <Ionicons 
                            name={isInMyTrips(destination.id) ? "checkmark" : "cart"} 
                            size={18} 
                            color={COLORS.white} 
                          />
                          <Text style={styles.cartButtonText}>
                            {isInMyTrips(destination.id) ? 'Booked' : 'Book Trip'}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Discover Places */}
          <View style={styles.discoverSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Discover Places</Text>
              <Text style={styles.resultCount}>{filteredDestinations.length} results</Text>
            </View>
            
            {filteredDestinations.map((destination) => (
              <TouchableOpacity 
                key={destination.id} 
                style={styles.discoverCard}
                onPress={() => navigateToDestinationDetails(destination)}
              >
                <Image source={{ uri: destination.image }} style={styles.discoverImage} />
                <View style={styles.discoverInfo}>
                  <View style={styles.discoverHeader}>
                    <View style={styles.titleContainer}>
                      <Text style={styles.discoverTitle}>{destination.name}</Text>
                      <View style={styles.categoryBadge}>
                        <Text style={styles.categoryBadgeText}>{destination.category}</Text>
                      </View>
                    </View>
                    <TouchableOpacity 
                      onPress={(e) => {
                        e.stopPropagation();
                        toggleWishlist(destination);
                      }}
                      style={styles.heartButton}
                    >
                      <Ionicons
                        name={isInWishlist(destination.id) ? 'heart' : 'heart-outline'}
                        size={20}
                        color={COLORS.accent}
                      />
                    </TouchableOpacity>
                  </View>
                  
                  <Text style={styles.discoverDescription}>{destination.description}</Text>
                  
                  <View style={styles.discoverStats}>
                    <View style={styles.statItem}>
                      <Ionicons name="time-outline" size={14} color={COLORS.textSecondary} />
                      <Text style={styles.statText}>{destination.duration}</Text>
                    </View>
                    <View style={styles.statItem}>
                      <Ionicons name="rocket-outline" size={14} color={COLORS.textSecondary} />
                      <Text style={styles.statText}>{destination.distance}</Text>
                    </View>
                    <View style={styles.statItem}>
                      <Ionicons name="star" size={14} color={COLORS.star} />
                      <Text style={styles.statText}>{destination.rating}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.discoverFooter}>
                    <View style={styles.priceTag}>
                      <Text style={styles.priceFrom}>from</Text>
                      <Text style={styles.discoverPrice}>
                        ${(destination.price / 1000).toFixed(0)}K
                      </Text>
                    </View>
                    <View style={styles.actionButtons}>
                      <TouchableOpacity 
                        style={[
                          styles.cartButtonSmall,
                          isInMyTrips(destination.id) && styles.cartButtonSmallAdded
                        ]}
                        onPress={(e) => {
                          e.stopPropagation();
                          if (!isInMyTrips(destination.id)) {
                            addToMyTrips(destination);
                          }
                        }}
                      >
                        <Ionicons 
                          name={isInMyTrips(destination.id) ? "checkmark" : "cart"} 
                          size={16} 
                          color={COLORS.white} 
                        />
                        <Text style={styles.cartButtonSmallText}>
                          {isInMyTrips(destination.id) ? 'Booked' : 'Book'}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};

// ... (keep all your existing styles exactly as they are)
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 20,
  },
  greeting: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  userName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  headerIcons: {
    flexDirection: 'row',
    gap: 12,
  },
  iconButton: {
    position: 'relative',
    padding: 8,
  },
  iconBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: COLORS.accent,
    width: 18,
    height: 18,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: 'bold',
  },
  searchSection: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.cardBg,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 8,
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    color: COLORS.white,
    fontSize: 16,
    paddingVertical: 12,
  },
  filterButton: {
    backgroundColor: COLORS.primary,
    padding: 8,
    borderRadius: 10,
    marginLeft: 8,
  },
  categorySection: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  seeAllText: {
    color: COLORS.accent,
    fontSize: 14,
    fontWeight: '600',
  },
  categoryContainer: {
    paddingLeft: 24,
  },
  categoryTab: {
    marginRight: 12,
    borderRadius: 20,
    overflow: 'hidden',
  },
  categoryGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
  },
  categoryTabActive: {
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  categoryText: {
    color: COLORS.textSecondary,
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '600',
  },
  categoryTextActive: {
    color: COLORS.white,
  },
  featuredSection: {
    marginBottom: 30,
  },
  featuredScroll: {
    paddingLeft: 24,
  },
  featuredCard: {
    width: width * 0.8,
    height: 320,
    marginRight: 16,
    borderRadius: 24,
    overflow: 'hidden',
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  featuredImage: {
    width: '100%',
    height: '100%',
  },
  featuredGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '65%',
    justifyContent: 'flex-end',
    padding: 20,
  },
  wishlistButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: 'rgba(30, 41, 59, 0.9)',
    padding: 10,
    borderRadius: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  featuredBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: COLORS.accent,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  featuredBadgeText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: 'bold',
  },
  featuredInfo: {
    marginBottom: 10,
  },
  featuredTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    fontFamily: 'System',
  },
  featuredDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  featuredFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: COLORS.white,
    marginLeft: 6,
    fontSize: 14,
    fontWeight: '600',
  },
  cartButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  cartButtonAdded: {
    backgroundColor: COLORS.success,
  },
  cartButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  discoverSection: {
    paddingHorizontal: 24,
    paddingBottom: 30,
  },
  resultCount: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  discoverCard: {
    flexDirection: 'row',
    backgroundColor: COLORS.cardBg,
    marginBottom: 16,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  discoverImage: {
    width: 120,
    height: 140,
  },
  discoverInfo: {
    flex: 1,
    padding: 16,
  },
  discoverHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  titleContainer: {
    flex: 1,
  },
  discoverTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 6,
    fontFamily: 'System',
  },
  categoryBadge: {
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  categoryBadgeText: {
    color: COLORS.primaryLight,
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  heartButton: {
    padding: 4,
  },
  discoverDescription: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginBottom: 12,
    lineHeight: 18,
  },
  discoverStats: {
    flexDirection: 'row',
    marginBottom: 12,
    gap: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginLeft: 4,
  },
  discoverFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceTag: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  priceFrom: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginRight: 4,
  },
  discoverPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.accent,
    fontFamily: 'System',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cartButtonSmall: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },
  cartButtonSmallAdded: {
    backgroundColor: COLORS.success,
  },
  cartButtonSmallText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
});

export default HomeScreen;