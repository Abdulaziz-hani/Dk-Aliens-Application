import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';

const { width } = Dimensions.get('window');

const DestinationDetailsScreen = ({ navigation, route }) => {
  const { destination } = route.params;
  const [isInWishlist, setIsInWishlist] = useState(route.params?.isInWishlist || false);
  const [isInMyTrips, setIsInMyTrips] = useState(route.params?.isInMyTrips || false);
  const [selectedTab, setSelectedTab] = useState('Overview');

  const tabs = ['Overview', 'Itinerary', 'Reviews', 'Gallery'];

  const features = [
    { icon: 'rocket-outline', title: 'Duration', value: destination.duration },
    { icon: 'location-outline', title: 'Distance', value: destination.distance },
    { icon: 'people-outline', title: 'Capacity', value: `${destination.capacity} seats` },
    { icon: 'star-outline', title: 'Rating', value: destination.rating },
  ];

  const highlights = [
    'Zero-gravity experience',
    'Panoramic observation deck',
    'Gourmet space cuisine',
    'Professional astronaut guides',
    'Emergency life support systems',
    'Virtual reality training',
  ];

  const reviews = [
    { id: 1, name: 'Alex Turner', rating: 5, comment: 'Absolutely incredible experience! The views were breathtaking.', date: '2 weeks ago' },
    { id: 2, name: 'Maria Santos', rating: 5, comment: 'Worth every penny. The staff were professional and the journey was smooth.', date: '1 month ago' },
    { id: 3, name: 'James Wilson', rating: 4, comment: 'Amazing adventure, though the trip was longer than expected.', date: '2 months ago' },
  ];

  const handleWishlistToggle = () => {
    setIsInWishlist(!isInWishlist);
  };

  const handleBookNow = () => {
    if (!isInMyTrips) {
      setIsInMyTrips(true);
      // Navigate to confirmation or booking screen
      navigation.navigate('BookingConfirmation', { destination });
    }
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero Image */}
        <View style={styles.heroSection}>
          <Image source={{ uri: destination.image }} style={styles.heroImage} />
          <LinearGradient
            colors={['transparent', 'rgba(10, 15, 28, 0.8)']}
            style={styles.heroGradient}
          />
          
          <SafeAreaView style={styles.heroHeader}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="arrow-back" size={24} color={COLORS.white} />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.wishlistButton}
              onPress={handleWishlistToggle}
            >
              <Ionicons 
                name={isInWishlist ? 'heart' : 'heart-outline'} 
                size={24} 
                color={COLORS.accent} 
              />
            </TouchableOpacity>
          </SafeAreaView>

          {destination.isFeatured && (
            <View style={styles.featuredBadge}>
              <Text style={styles.featuredBadgeText}>FEATURED</Text>
            </View>
          )}
        </View>

        {/* Content */}
        <View style={styles.content}>
          {/* Title Section */}
          <View style={styles.titleSection}>
            <View style={styles.titleRow}>
              <View style={styles.categoryBadge}>
                <Text style={styles.categoryText}>{destination.category}</Text>
              </View>
              <View style={styles.ratingContainer}>
                <Ionicons name="star" size={18} color={COLORS.star} />
                <Text style={styles.ratingText}>{destination.rating}</Text>
                <Text style={styles.reviewCount}>(124 reviews)</Text>
              </View>
            </View>
            
            <Text style={styles.destinationTitle}>{destination.name}</Text>
            <Text style={styles.destinationDescription}>{destination.description}</Text>
          </View>

          {/* Features Grid */}
          <View style={styles.featuresSection}>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => (
                <View key={index} style={styles.featureCard}>
                  <LinearGradient
                    colors={[COLORS.cardBg, COLORS.cardBgLight]}
                    style={styles.featureGradient}
                  >
                    <Ionicons name={feature.icon} size={28} color={COLORS.primary} />
                    <Text style={styles.featureTitle}>{feature.title}</Text>
                    <Text style={styles.featureValue}>{feature.value}</Text>
                  </LinearGradient>
                </View>
              ))}
            </View>
          </View>

          {/* Tabs */}
          <View style={styles.tabsSection}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {tabs.map((tab) => (
                <TouchableOpacity
                  key={tab}
                  style={[styles.tab, selectedTab === tab && styles.tabActive]}
                  onPress={() => setSelectedTab(tab)}
                >
                  <Text style={[styles.tabText, selectedTab === tab && styles.tabTextActive]}>
                    {tab}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Tab Content */}
          {selectedTab === 'Overview' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Experience Highlights</Text>
              {highlights.map((highlight, index) => (
                <View key={index} style={styles.highlightItem}>
                  <Ionicons name="checkmark-circle" size={20} color={COLORS.success} />
                  <Text style={styles.highlightText}>{highlight}</Text>
                </View>
              ))}
            </View>
          )}

          {selectedTab === 'Itinerary' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Trip Itinerary</Text>
              <View style={styles.itineraryItem}>
                <View style={styles.itineraryDot} />
                <View style={styles.itineraryContent}>
                  <Text style={styles.itineraryDay}>Day 1</Text>
                  <Text style={styles.itineraryTitle}>Launch & Departure</Text>
                  <Text style={styles.itineraryDescription}>
                    Pre-flight briefing, suit-up, and launch from Earth's spaceport
                  </Text>
                </View>
              </View>
              <View style={styles.itineraryItem}>
                <View style={styles.itineraryDot} />
                <View style={styles.itineraryContent}>
                  <Text style={styles.itineraryDay}>Day 2-7</Text>
                  <Text style={styles.itineraryTitle}>Space Travel</Text>
                  <Text style={styles.itineraryDescription}>
                    Experience zero gravity, view Earth from space, participate in activities
                  </Text>
                </View>
              </View>
              <View style={styles.itineraryItem}>
                <View style={styles.itineraryDot} />
                <View style={styles.itineraryContent}>
                  <Text style={styles.itineraryDay}>Day 8</Text>
                  <Text style={styles.itineraryTitle}>Arrival & Exploration</Text>
                  <Text style={styles.itineraryDescription}>
                    Land on destination, explore surface, conduct experiments
                  </Text>
                </View>
              </View>
            </View>
          )}

          {selectedTab === 'Reviews' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Traveler Reviews</Text>
              {reviews.map((review) => (
                <View key={review.id} style={styles.reviewCard}>
                  <LinearGradient
                    colors={[COLORS.cardBg, COLORS.cardBgLight]}
                    style={styles.reviewGradient}
                  >
                    <View style={styles.reviewHeader}>
                      <View style={styles.reviewerInfo}>
                        <View style={styles.reviewerAvatar}>
                          <Ionicons name="person" size={20} color={COLORS.white} />
                        </View>
                        <View>
                          <Text style={styles.reviewerName}>{review.name}</Text>
                          <Text style={styles.reviewDate}>{review.date}</Text>
                        </View>
                      </View>
                      <View style={styles.reviewRating}>
                        {[...Array(review.rating)].map((_, i) => (
                          <Ionicons key={i} name="star" size={14} color={COLORS.star} />
                        ))}
                      </View>
                    </View>
                    <Text style={styles.reviewComment}>{review.comment}</Text>
                  </LinearGradient>
                </View>
              ))}
            </View>
          )}

          {selectedTab === 'Gallery' && (
            <View style={styles.tabContent}>
              <Text style={styles.sectionTitle}>Photo Gallery</Text>
              <View style={styles.galleryGrid}>
                {[1, 2, 3, 4, 5, 6].map((item) => (
                  <View key={item} style={styles.galleryItem}>
                    <Image 
                      source={{ uri: destination.image }} 
                      style={styles.galleryImage} 
                    />
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>
      </ScrollView>

      {/* Bottom Bar */}
      <View style={styles.bottomBar}>
        <LinearGradient
          colors={[COLORS.cardBg, COLORS.background]}
          style={styles.bottomGradient}
        >
          <View style={styles.priceSection}>
            <View>
              <Text style={styles.priceLabel}>Total Price</Text>
              <Text style={styles.priceAmount}>${(destination.price / 1000).toFixed(0)}K</Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={[styles.bookButton, isInMyTrips && styles.bookButtonBooked]}
            onPress={handleBookNow}
          >
            <Text style={styles.bookButtonText}>
              {isInMyTrips ? 'Booked' : 'Book Now'}
            </Text>
            <Ionicons 
              name={isInMyTrips ? 'checkmark' : 'rocket'} 
              size={20} 
              color={COLORS.white} 
            />
          </TouchableOpacity>
        </LinearGradient>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  heroSection: {
    position: 'relative',
    height: 400,
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  heroGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
  },
  heroHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  backButton: {
    backgroundColor: 'rgba(26, 31, 58, 0.9)',
    padding: 12,
    borderRadius: 20,
  },
  wishlistButton: {
    backgroundColor: 'rgba(26, 31, 58, 0.9)',
    padding: 12,
    borderRadius: 20,
  },
  featuredBadge: {
    position: 'absolute',
    top: 80,
    left: 24,
    backgroundColor: COLORS.accent,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  featuredBadgeText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  content: {
    padding: 24,
  },
  titleSection: {
    marginBottom: 24,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  categoryBadge: {
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  categoryText: {
    color: COLORS.primaryLight,
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  reviewCount: {
    color: COLORS.textSecondary,
    fontSize: 14,
    marginLeft: 4,
  },
  destinationTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 12,
    fontFamily: 'System',
  },
  destinationDescription: {
    fontSize: 16,
    color: COLORS.textSecondary,
    lineHeight: 24,
  },
  featuresSection: {
    marginBottom: 24,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    width: '48%',
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  featureGradient: {
    padding: 20,
    alignItems: 'center',
  },
  featureTitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 8,
    marginBottom: 4,
  },
  featureValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  tabsSection: {
    marginBottom: 24,
  },
  tab: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    marginRight: 12,
    backgroundColor: COLORS.cardBg,
    borderRadius: 12,
  },
  tabActive: {
    backgroundColor: COLORS.primary,
  },
  tabText: {
    color: COLORS.textSecondary,
    fontSize: 14,
    fontWeight: '600',
  },
  tabTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  tabContent: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 16,
    fontFamily: 'System',
  },
  highlightItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  highlightText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginLeft: 12,
  },
  itineraryItem: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  itineraryDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.primary,
    marginTop: 4,
    marginRight: 16,
  },
  itineraryContent: {
    flex: 1,
  },
  itineraryDay: {
    fontSize: 14,
    color: COLORS.accent,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  itineraryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
  },
  itineraryDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  reviewCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  reviewGradient: {
    padding: 16,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  reviewerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reviewerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  reviewerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.white,
  },
  reviewDate: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  reviewRating: {
    flexDirection: 'row',
  },
  reviewComment: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  galleryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  galleryItem: {
    width: '48%',
    height: 120,
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  galleryImage: {
    width: '100%',
    height: '100%',
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  bottomGradient: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 20,
    paddingBottom: 30,
  },
  priceSection: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  priceAmount: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.accent,
    fontFamily: 'System',
  },
  bookButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  bookButtonBooked: {
    backgroundColor: COLORS.success,
  },
  bookButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
  },
});

export default DestinationDetailsScreen;