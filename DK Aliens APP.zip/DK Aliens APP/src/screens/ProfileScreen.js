import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  SafeAreaView,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';

const ProfileScreen = ({ navigation }) => {
  const profileOptions = [
    {
      id: '1',
      title: 'About Us',
      icon: 'information-circle',
      route: 'AboutUs',
      color: COLORS.accent,
      description: 'Learn about our mission',
    },
    {
      id: '2',
      title: 'Edit Profile',
      icon: 'person',
      color: COLORS.primary,
      description: 'Update your information',
    },
    {
      id: '3',
      title: 'Notifications',
      icon: 'notifications',
      badge: '3',
      color: COLORS.warning,
      description: 'Manage your alerts',
    },
    {
      id: '4',
      title: 'Payment Methods',
      icon: 'card',
      color: COLORS.success,
      description: 'Add payment options',
    },
    {
      id: '5',
      title: 'Travel Documents',
      icon: 'document-text',
      color: COLORS.secondary,
      description: 'Passport & visas',
    },
    {
      id: '6',
      title: 'Settings',
      icon: 'settings',
      color: COLORS.textSecondary,
      description: 'App preferences',
    },
    {
      id: '7',
      title: 'Help & Support',
      icon: 'help-circle',
      color: COLORS.primaryLight,
      description: 'Get assistance',
    },
    {
      id: '8',
      title: 'Logout',
      icon: 'log-out',
      color: COLORS.error,
      description: 'Sign out of account',
    },
  ];

  const handleOptionPress = (option) => {
    if (option.route) {
      navigation.navigate(option.route);
    } else {
      console.log(`${option.title} pressed`);
    }
  };

  const recentActivities = [
    { id: '1', type: 'booking', title: 'Mars Trip Booked', date: '2 days ago', icon: 'rocket' },
    { id: '2', type: 'payment', title: 'Payment Received', date: '1 week ago', icon: 'card' },
    { id: '3', type: 'review', title: 'Review Submitted', date: '2 weeks ago', icon: 'star' },
  ];

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
          {/* Enhanced Header */}
          <View style={styles.header}>
            <View>
              <Text style={styles.headerTitle}>Profile</Text>
              <Text style={styles.headerSubtitle}>Manage your cosmic account</Text>
            </View>
            <TouchableOpacity style={styles.editButton}>
              <Ionicons name="create" size={22} color={COLORS.white} />
            </TouchableOpacity>
          </View>

          {/* Enhanced Profile Info Card */}
          <View style={styles.profileSection}>
            <LinearGradient
              colors={[COLORS.primary, COLORS.secondary]}
              style={styles.profileCard}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.profileHeader}>
                <View style={styles.avatarContainer}>
                  <LinearGradient
                    colors={[COLORS.accent, COLORS.accentLight]}
                    style={styles.avatar}
                  >
                    <Ionicons name="person" size={40} color={COLORS.white} />
                  </LinearGradient>
                  <View style={styles.onlineBadge} />
                  <TouchableOpacity style={styles.cameraButton}>
                    <Ionicons name="camera" size={16} color={COLORS.white} />
                  </TouchableOpacity>
                </View>
                
                <View style={styles.profileInfo}>
                  <Text style={styles.userName}>Space Traveler</Text>
                  <Text style={styles.userEmail}>traveler@spaceapp.com</Text>
                  <Text style={styles.memberSince}>Member since 2024</Text>
                </View>
              </View>
              
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>12</Text>
                  <Text style={styles.statLabel}>Trips</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>8</Text>
                  <Text style={styles.statLabel}>Destinations</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>4.9</Text>
                  <Text style={styles.statLabel}>Rating</Text>
                </View>
                <View style={styles.statDivider} />
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>2</Text>
                  <Text style={styles.statLabel}>Badges</Text>
                </View>
              </View>
            </LinearGradient>
          </View>

          {/* Recent Activity */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <View style={styles.activityContainer}>
              {recentActivities.map((activity, index) => (
                <TouchableOpacity
                  key={activity.id}
                  style={[
                    styles.activityItem,
                    index === recentActivities.length - 1 && styles.activityItemLast,
                  ]}
                >
                  <View style={styles.activityIcon}>
                    <Ionicons name={activity.icon} size={20} color={COLORS.primary} />
                  </View>
                  <View style={styles.activityInfo}>
                    <Text style={styles.activityTitle}>{activity.title}</Text>
                    <Text style={styles.activityDate}>{activity.date}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={COLORS.textSecondary} />
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Enhanced Options List */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Account Settings</Text>
            <View style={styles.optionsContainer}>
              {profileOptions.map((option, index) => (
                <TouchableOpacity
                  key={option.id}
                  style={[
                    styles.optionItem,
                    index === profileOptions.length - 1 && styles.optionItemLast,
                  ]}
                  onPress={() => handleOptionPress(option)}
                >
                  <View style={styles.optionLeft}>
                    <LinearGradient
                      colors={[option.color, option.color + 'CC']}
                      style={styles.optionIcon}
                    >
                      <Ionicons name={option.icon} size={22} color={COLORS.white} />
                    </LinearGradient>
                    <View style={styles.optionText}>
                      <Text style={styles.optionTitle}>{option.title}</Text>
                      <Text style={styles.optionDescription}>{option.description}</Text>
                    </View>
                  </View>
                  <View style={styles.optionRight}>
                    {option.badge && (
                      <View style={styles.badge}>
                        <Text style={styles.badgeText}>{option.badge}</Text>
                      </View>
                    )}
                    <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* App Version */}
          <View style={styles.versionContainer}>
            <Text style={styles.versionText}>Space Travel v1.0.0</Text>
            <Text style={styles.versionSubtext}>Explore the cosmos with us</Text>
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  headerSubtitle: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  editButton: {
    backgroundColor: COLORS.cardBg,
    padding: 12,
    borderRadius: 12,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  profileSection: {
    paddingHorizontal: 24,
    marginBottom: 30,
  },
  profileCard: {
    borderRadius: 28,
    padding: 24,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 16,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: COLORS.white,
  },
  onlineBadge: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: COLORS.success,
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
  cameraButton: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    backgroundColor: COLORS.primary,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 4,
    fontFamily: 'System',
  },
  userEmail: {
    fontSize: 16,
    color: COLORS.white + 'CC',
    marginBottom: 4,
  },
  memberSince: {
    fontSize: 14,
    color: COLORS.white + '99',
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 20,
    padding: 16,
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 4,
    fontFamily: 'System',
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.white + 'CC',
    fontWeight: '600',
  },
  statDivider: {
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  section: {
    paddingHorizontal: 24,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 16,
    fontFamily: 'System',
  },
  activityContainer: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primaryDark,
  },
  activityItemLast: {
    borderBottomWidth: 0,
  },
  activityIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.primary + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  activityInfo: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.white,
    marginBottom: 4,
  },
  activityDate: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  optionsContainer: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  optionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.primaryDark,
  },
  optionItemLast: {
    borderBottomWidth: 0,
  },
  optionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  optionIcon: {
    width: 50,
    height: 50,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  optionText: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.white,
    marginBottom: 4,
  },
  optionDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  optionRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  badge: {
    backgroundColor: COLORS.error,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    marginRight: 12,
  },
  badgeText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  versionContainer: {
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 24,
  },
  versionText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginBottom: 8,
    fontWeight: '600',
  },
  versionSubtext: {
    fontSize: 14,
    color: COLORS.gray,
  },
});

export default ProfileScreen;