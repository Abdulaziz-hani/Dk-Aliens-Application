import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';
import { useData } from '../context/DataContext';

const MyTripsScreen = ({ navigation }) => {
  const [activeTab, setActiveTab] = useState('Upcoming');
  
  const {
    myTrips,
    updateTripStatus,
  } = useData();

  // Update the DataContext to include updateTripStatus function
  // Add this to your DataContext.js:
  /*
  const updateTripStatus = (tripId, newStatus) => {
    const updatedTrips = myTrips.map(trip => 
      trip.id === tripId ? { ...trip, status: newStatus } : trip
    );
    setMyTrips(updatedTrips);
  };
  */

  // Categorize trips based on status
  const categorizedTrips = {
    upcoming: myTrips.filter(trip => trip.status === 'Confirmed'),
    completed: myTrips.filter(trip => trip.status === 'Completed'),
    cancelled: myTrips.filter(trip => trip.status === 'Cancelled'),
  };

  const currentTrips = categorizedTrips[activeTab.toLowerCase()] || [];

  const StatusBadge = ({ status }) => {
    const getStatusConfig = () => {
      switch (status) {
        case 'Confirmed':
          return { color: COLORS.success, icon: 'checkmark-circle' };
        case 'Pending Payment':
          return { color: COLORS.warning, icon: 'time' };
        case 'Completed':
          return { color: COLORS.accent, icon: 'rocket' };
        case 'Cancelled':
          return { color: COLORS.error, icon: 'close-circle' };
        default:
          return { color: COLORS.gray, icon: 'close-circle' };
      }
    };

    const config = getStatusConfig();

    return (
      <View style={[styles.statusBadge, { backgroundColor: config.color + '20' }]}>
        <Ionicons name={config.icon} size={14} color={config.color} style={styles.statusIcon} />
        <Text style={[styles.statusText, { color: config.color }]}>{status}</Text>
      </View>
    );
  };

  const cancelTrip = (tripId) => {
    updateTripStatus(tripId, 'Cancelled');
  };

  const completeTrip = (tripId) => {
    updateTripStatus(tripId, 'Completed');
  };

  const downloadTicket = (trip) => {
    // Simulate ticket download
    console.log('Downloading ticket for', trip.name);
    alert(`Ticket for ${trip.name} downloaded!`);
  };

  const exploreMore = () => {
    navigation.navigate('Explore');
  };

  const viewTripDetails = (trip) => {
    navigation.navigate('TripDetails', { trip });
  };

  // First, update your DataContext.js to include the updateTripStatus function:
  /*
  const updateTripStatus = (tripId, newStatus) => {
    const updatedTrips = myTrips.map(trip => 
      trip.id === tripId ? { ...trip, status: newStatus } : trip
    );
    setMyTrips(updatedTrips);
  };
  */

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.headerTitle}>My Trips</Text>
            <Text style={styles.headerSubtitle}>
              {myTrips.length} total adventure{myTrips.length !== 1 ? 's' : ''}
            </Text>
          </View>
          <TouchableOpacity 
            style={styles.calendarButton}
            onPress={() => console.log('Calendar view')}
          >
            <Ionicons name="calendar" size={24} color={COLORS.white} />
          </TouchableOpacity>
        </View>

        {/* Tabs */}
        <View style={styles.tabContainer}>
          {['Upcoming', 'Completed', 'Cancelled'].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeTab === tab && styles.tabActive]}
              onPress={() => setActiveTab(tab)}
            >
              <LinearGradient
                colors={activeTab === tab ? 
                  [COLORS.primary, COLORS.primaryDark] : 
                  [COLORS.cardBg, COLORS.cardBgLight]
                }
                style={styles.tabGradient}
              >
                <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
                  {tab}
                </Text>
                <View style={styles.tabCount}>
                  <Text style={[styles.tabCountText, activeTab === tab && styles.tabCountTextActive]}>
                    {categorizedTrips[tab.toLowerCase()]?.length || 0}
                  </Text>
                </View>
                {activeTab === tab && (
                  <View style={styles.tabIndicator} />
                )}
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>

        {/* Trip List */}
        <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
          {currentTrips.length === 0 ? (
            <View style={styles.emptyContainer}>
              <LinearGradient
                colors={[COLORS.cardBg, COLORS.cardBgLight]}
                style={styles.emptyCard}
              >
                <Ionicons 
                  name={activeTab === 'Upcoming' ? 'rocket-outline' : activeTab === 'Completed' ? 'checkmark-done' : 'close-circle'} 
                  size={80} 
                  color={COLORS.primary} 
                />
                <Text style={styles.emptyTitle}>No {activeTab.toLowerCase()} trips</Text>
                <Text style={styles.emptyText}>
                  {activeTab === 'Upcoming' 
                    ? 'Start exploring and book your cosmic adventure today!'
                    : activeTab === 'Completed'
                    ? 'Your completed adventures will appear here'
                    : 'Cancelled trips will appear here'
                  }
                </Text>
                {activeTab === 'Upcoming' && (
                  <TouchableOpacity 
                    style={styles.exploreButton}
                    onPress={exploreMore}
                  >
                    <Text style={styles.exploreButtonText}>Explore Destinations</Text>
                    <Ionicons name="arrow-forward" size={16} color={COLORS.white} />
                  </TouchableOpacity>
                )}
              </LinearGradient>
            </View>
          ) : (
            currentTrips.map((trip) => (
              <View key={trip.id} style={styles.tripCard}>
                <Image source={{ uri: trip.image }} style={styles.tripImage} />
                <LinearGradient
                  colors={['transparent', 'rgba(10, 15, 28, 0.95)']}
                  style={styles.tripGradient}
                />
                
                {/* Status Overlay */}
                <View style={styles.statusOverlay}>
                  <StatusBadge status={trip.status} />
                </View>

                {/* Category Badge */}
                <View style={styles.categoryOverlay}>
                  <View style={styles.categoryBadge}>
                    <Ionicons name="planet" size={12} color={COLORS.primaryLight} />
                    <Text style={styles.categoryBadgeText}>{trip.category}</Text>
                  </View>
                </View>

                <View style={styles.tripContent}>
                  <View style={styles.tripHeader}>
                    <View style={styles.tripTitleContainer}>
                      <Text style={styles.tripDestination}>{trip.name}</Text>
                      <View style={styles.ratingContainer}>
                        <Ionicons name="star" size={14} color={COLORS.star} />
                        <Text style={styles.ratingText}>{trip.rating}</Text>
                      </View>
                    </View>
                    
                    <View style={styles.priceTag}>
                      <Text style={styles.priceLabel}>Total</Text>
                      <Text style={styles.priceValue}>${(trip.price / 1000).toFixed(0)}K</Text>
                    </View>
                  </View>
                  
                  <Text style={styles.tripDescription} numberOfLines={2}>
                    {trip.description}
                  </Text>
                  
                  <View style={styles.tripDetails}>
                    <View style={styles.detailGrid}>
                      <View style={styles.detailItem}>
                        <Ionicons name="calendar" size={16} color={COLORS.accent} />
                        <Text style={styles.detailLabel}>Departure</Text>
                        <Text style={styles.detailText}>{trip.date}</Text>
                      </View>
                      
                      <View style={styles.detailItem}>
                        <Ionicons name="time" size={16} color={COLORS.accent} />
                        <Text style={styles.detailLabel}>Duration</Text>
                        <Text style={styles.detailText}>{trip.duration}</Text>
                      </View>
                      
                      <View style={styles.detailItem}>
                        <Ionicons name="people" size={16} color={COLORS.accent} />
                        <Text style={styles.detailLabel}>Travelers</Text>
                        <Text style={styles.detailText}>{trip.travelers}</Text>
                      </View>
                      
                      <View style={styles.detailItem}>
                        <Ionicons name="rocket" size={16} color={COLORS.accent} />
                        <Text style={styles.detailLabel}>Distance</Text>
                        <Text style={styles.detailText}>{trip.distance}</Text>
                      </View>
                    </View>

                    <View style={styles.bookingInfo}>
                      <Ionicons name="pricetag" size={14} color={COLORS.textSecondary} />
                      <Text style={styles.bookingId}>{trip.bookingId}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.tripActions}>
                    <TouchableOpacity 
                      style={styles.primaryButton}
                      onPress={() => viewTripDetails(trip)}
                    >
                      <Ionicons name="information-circle" size={18} color={COLORS.white} />
                      <Text style={styles.primaryButtonText}>Details</Text>
                    </TouchableOpacity>
                    
                    {trip.status === 'Confirmed' && (
                      <TouchableOpacity 
                        style={styles.secondaryButton}
                        onPress={() => downloadTicket(trip)}
                      >
                        <Ionicons name="download" size={18} color={COLORS.primary} />
                        <Text style={styles.secondaryButtonText}>Ticket</Text>
                      </TouchableOpacity>
                    )}
                    
                    {trip.status === 'Confirmed' ? (
                      <View style={styles.actionGroup}>
                        <TouchableOpacity 
                          style={styles.completeButton}
                          onPress={() => completeTrip(trip.id)}
                        >
                          <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                        </TouchableOpacity>
                        
                        <TouchableOpacity 
                          style={styles.cancelButton}
                          onPress={() => cancelTrip(trip.id)}
                        >
                          <Ionicons name="close-circle" size={16} color={COLORS.error} />
                        </TouchableOpacity>
                      </View>
                    ) : (
                      <View style={styles.statusMessage}>
                        <Ionicons 
                          name={trip.status === 'Completed' ? 'checkmark-done' : 'information'} 
                          size={16} 
                          color={trip.status === 'Completed' ? COLORS.success : COLORS.textSecondary} 
                        />
                        <Text style={[
                          styles.statusMessageText,
                          { color: trip.status === 'Completed' ? COLORS.success : COLORS.textSecondary }
                        ]}>
                          {trip.status === 'Completed' ? 'Trip Completed' : 'Trip Cancelled'}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            ))
          )}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  headerSubtitle: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  calendarButton: {
    backgroundColor: COLORS.cardBg,
    padding: 12,
    borderRadius: 12,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    marginBottom: 24,
    backgroundColor: COLORS.cardBg,
    marginHorizontal: 24,
    borderRadius: 16,
    padding: 4,
  },
  tab: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
  },
  tabGradient: {
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
  tabActive: {
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  tabText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  tabTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  tabCount: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: COLORS.primary + '40',
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabCountText: {
    fontSize: 10,
    color: COLORS.textSecondary,
    fontWeight: 'bold',
  },
  tabCountTextActive: {
    color: COLORS.white,
  },
  tabIndicator: {
    position: 'absolute',
    bottom: 4,
    width: 20,
    height: 3,
    backgroundColor: COLORS.white,
    borderRadius: 2,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 60,
  },
  emptyCard: {
    alignItems: 'center',
    padding: 40,
    borderRadius: 24,
    width: '100%',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.white,
    marginTop: 20,
    marginBottom: 12,
    fontFamily: 'System',
  },
  emptyText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 22,
  },
  exploreButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  exploreButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
  },
  tripCard: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 24,
    marginBottom: 20,
    overflow: 'hidden',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
    position: 'relative',
  },
  tripImage: {
    width: '100%',
    height: 200,
  },
  tripGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '100%',
  },
  statusOverlay: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 2,
  },
  categoryOverlay: {
    position: 'absolute',
    top: 16,
    left: 16,
    zIndex: 2,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  statusIcon: {
    marginRight: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  categoryBadgeText: {
    color: COLORS.primaryLight,
    fontSize: 11,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    marginLeft: 4,
  },
  tripContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
  },
  tripHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  tripTitleContainer: {
    flex: 1,
    marginRight: 16,
  },
  tripDestination: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    fontFamily: 'System',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  priceTag: {
    alignItems: 'flex-end',
  },
  priceLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 2,
  },
  priceValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.accent,
    fontFamily: 'System',
  },
  tripDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
    lineHeight: 18,
  },
  tripDetails: {
    marginBottom: 16,
  },
  detailGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  detailItem: {
    width: '48%',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
  },
  detailLabel: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginLeft: 6,
    marginRight: 4,
    fontWeight: '600',
  },
  detailText: {
    fontSize: 12,
    color: COLORS.white,
    fontWeight: 'bold',
  },
  bookingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    borderLeftWidth: 3,
    borderLeftColor: COLORS.primary,
  },
  bookingId: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginLeft: 6,
    fontFamily: 'monospace',
    fontWeight: '600',
  },
  tripActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  primaryButton: {
    flex: 1,
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: COLORS.cardBgLight,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.primary + '30',
  },
  secondaryButtonText: {
    color: COLORS.primary,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  actionGroup: {
    flex: 2,
    flexDirection: 'row',
    gap: 6,
  },
  completeButton: {
    flex: 1,
    backgroundColor: COLORS.success + '20',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.success + '40',
  },
  completeButtonText: {
    color: COLORS.success,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: COLORS.error + '20',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.error + '40',
  },
  cancelButtonText: {
    color: COLORS.error,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  statusMessage: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  statusMessageText: {
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 6,
  },
});

export default MyTripsScreen;