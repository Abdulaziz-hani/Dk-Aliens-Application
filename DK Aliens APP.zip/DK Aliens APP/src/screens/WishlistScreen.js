import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';
import { useData } from '../context/DataContext';

const WishlistScreen = ({ navigation }) => {
  const {
    wishlist,
    removeFromWishlist,
    addToMyTrips,
    myTrips,
  } = useData();

  const handleBookTrip = (item) => {
    addToMyTrips(item);
    removeFromWishlist(item.id);
  };

  const handleExplore = () => {
    navigation.navigate('Explore');
  };

  const clearAllWishlist = () => {
    wishlist.forEach(item => removeFromWishlist(item.id));
  };

  const navigateToDestinationDetails = (item) => {
    navigation.navigate('DestinationDetails', {
      destination: item,
      isInWishlist: true,
      isInMyTrips: myTrips.some(trip => trip.id === item.id),
    });
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Ionicons name="chevron-back" size={24} color={COLORS.white} />
            </TouchableOpacity>
            <View>
              <Text style={styles.headerTitle}>Wishlist</Text>
              <Text style={styles.headerSubtitle}>{wishlist.length} cosmic destinations</Text>
            </View>
          </View>
          {wishlist.length > 0 && (
            <TouchableOpacity 
              style={styles.clearButton}
              onPress={clearAllWishlist}
            >
              <Text style={styles.clearButtonText}>Clear All</Text>
            </TouchableOpacity>
          )}
        </View>

        <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
          {wishlist.length === 0 ? (
            <View style={styles.emptyContainer}>
              <LinearGradient
                colors={[COLORS.cardBg, COLORS.cardBgLight]}
                style={styles.emptyCard}
              >
                <Ionicons name="heart-outline" size={80} color={COLORS.primary} />
                <Text style={styles.emptyTitle}>Your wishlist is empty</Text>
                <Text style={styles.emptyText}>
                  Start adding your favorite destinations to plan your cosmic journey
                </Text>
                <TouchableOpacity 
                  style={styles.exploreButton}
                  onPress={handleExplore}
                >
                  <Text style={styles.exploreButtonText}>Explore Space</Text>
                  <Ionicons name="rocket" size={16} color={COLORS.white} />
                </TouchableOpacity>
              </LinearGradient>
            </View>
          ) : (
            <View style={styles.wishlistGrid}>
              {wishlist.map((item) => (
                <TouchableOpacity 
                  key={item.id} 
                  style={styles.wishlistCard}
                  onPress={() => navigateToDestinationDetails(item)}
                >
                  <Image source={{ uri: item.image }} style={styles.cardImage} />
                  <LinearGradient
                    colors={['transparent', 'rgba(10, 15, 28, 0.95)']}
                    style={styles.cardGradient}
                  />
                  
                  <TouchableOpacity 
                    style={styles.heartButton}
                    onPress={(e) => {
                      e.stopPropagation();
                      removeFromWishlist(item.id);
                    }}
                  >
                    <LinearGradient
                      colors={[COLORS.primary, COLORS.primaryDark]}
                      style={styles.heartGradient}
                    >
                      <Ionicons name="heart" size={20} color={COLORS.white} />
                    </LinearGradient>
                  </TouchableOpacity>
                  
                  <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                      <View style={styles.categoryBadge}>
                        <Text style={styles.categoryText}>{item.category}</Text>
                      </View>
                      <View style={styles.ratingContainer}>
                        <Ionicons name="star" size={14} color={COLORS.star} />
                        <Text style={styles.ratingText}>{item.rating}</Text>
                      </View>
                    </View>
                    
                    <Text style={styles.cardTitle}>{item.name}</Text>
                    <Text style={styles.cardDescription} numberOfLines={2}>
                      {item.description}
                    </Text>
                    
                    <View style={styles.cardFooter}>
                      <View style={styles.priceContainer}>
                        <Text style={styles.priceLabel}>From</Text>
                        <Text style={styles.priceValue}>
                          ${(item.price / 1000).toFixed(0)}K
                        </Text>
                      </View>
                      
                      <View style={styles.actionButtons}>
                        <TouchableOpacity 
                          style={styles.bookButton}
                          onPress={(e) => {
                            e.stopPropagation();
                            handleBookTrip(item);
                          }}
                        >
                          <Ionicons name="rocket" size={16} color={COLORS.white} />
                          <Text style={styles.bookButtonText}>BOOK</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                    
                    <View style={styles.distanceContainer}>
                      <Ionicons name="time" size={12} color={COLORS.textSecondary} />
                      <Text style={styles.distanceText}>{item.duration}</Text>
                      <Ionicons name="rocket" size={12} color={COLORS.textSecondary} style={styles.distanceIcon} />
                      <Text style={styles.distanceText}>{item.distance}</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 24,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    padding: 8,
    marginRight: 16,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  headerSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  clearButton: {
    backgroundColor: COLORS.error + '20',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  clearButtonText: {
    color: COLORS.error,
    fontSize: 12,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 80,
  },
  emptyCard: {
    alignItems: 'center',
    padding: 40,
    borderRadius: 24,
    width: '100%',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.white,
    marginTop: 20,
    marginBottom: 12,
    fontFamily: 'System',
  },
  emptyText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 22,
  },
  exploreButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 16,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  exploreButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
  },
  wishlistGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  wishlistCard: {
    width: '100%',
    height: 280,
    marginBottom: 20,
    borderRadius: 24,
    overflow: 'hidden',
    position: 'relative',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '70%',
  },
  heartButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  heartGradient: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryBadge: {
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  categoryText: {
    color: COLORS.primaryLight,
    fontSize: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(30, 41, 59, 0.8)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    fontFamily: 'System',
  },
  cardDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
    lineHeight: 18,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  priceLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginRight: 4,
  },
  priceValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.accent,
    fontFamily: 'System',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  bookButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  bookButtonText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 6,
  },
  distanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  distanceIcon: {
    marginLeft: 12,
  },
  distanceText: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginLeft: 4,
  },
});

export default WishlistScreen;