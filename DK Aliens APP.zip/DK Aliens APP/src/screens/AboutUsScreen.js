import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';

const AboutUsScreen = () => {
  const teamMembers = [
    { name: 'Dr. Sarah Chen', role: 'CEO & Founder', icon: 'person', color: COLORS.primary },
    { name: 'Marcus Rodriguez', role: 'Chief Space Officer', icon: 'rocket', color: COLORS.accent },
    { name: 'Emily Watson', role: 'Head of Experience', icon: 'star', color: COLORS.secondary },
    { name: 'Dr. James Park', role: 'Safety Director', icon: 'shield-checkmark', color: COLORS.tertiary },
  ];

  const features = [
    {
      icon: 'shield-checkmark',
      title: 'Safety First',
      description: 'Certified by International Space Tourism Board',
      color: COLORS.success,
    },
    {
      icon: 'planet',
      title: '50+ Destinations',
      description: 'Explore the solar system and beyond',
      color: COLORS.accent,
    },
    {
      icon: 'people',
      title: '10K+ Travelers',
      description: 'Join our community of space explorers',
      color: COLORS.primary,
    },
    {
      icon: 'star',
      title: '4.9 Rating',
      description: 'Trusted by cosmic adventurers worldwide',
      color: COLORS.warning,
    },
  ];

  const handleSocialPress = (platform) => {
    const urls = {
      website: 'https://spacetravel.app',
      email: 'mailto:hello@spacetravel.app',
      twitter: 'https://twitter.com/spacetravel',
      instagram: 'https://instagram.com/spacetravel',
    };
    Linking.openURL(urls[platform]);
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* Enhanced Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.logoContainer}>
            <LinearGradient
              colors={[COLORS.primary, COLORS.secondary]}
              style={styles.logoGradient}
            >
              <Ionicons name="planet" size={80} color={COLORS.white} />
            </LinearGradient>
          </View>
          <Text style={styles.appName}>Space Travel</Text>
          <Text style={styles.tagline}>Discover a Universe of Opportunity</Text>
          <View style={styles.glowEffect} />
        </View>

        {/* Enhanced Mission Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Our Mission</Text>
          <LinearGradient
            colors={[COLORS.cardBg, COLORS.cardBgLight]}
            style={styles.missionCard}
          >
            <View style={styles.missionIcon}>
              <Ionicons name="rocket" size={32} color={COLORS.accent} />
            </View>
            <Text style={styles.missionText}>
              We're pioneering the future of space tourism, making the cosmos accessible to
              everyone. Our mission is to transform humanity into a multi-planetary species while
              providing unforgettable experiences beyond Earth.
            </Text>
          </LinearGradient>
        </View>

        {/* Enhanced Features Grid */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Why Choose Us</Text>
          <View style={styles.featuresGrid}>
            {features.map((feature, index) => (
              <LinearGradient
                key={index}
                colors={[COLORS.cardBg, COLORS.cardBgLight]}
                style={styles.featureCard}
              >
                <View style={[styles.featureIcon, { backgroundColor: feature.color + '20' }]}>
                  <Ionicons name={feature.icon} size={32} color={feature.color} />
                </View>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDescription}>{feature.description}</Text>
              </LinearGradient>
            ))}
          </View>
        </View>

        {/* Enhanced Team Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Meet Our Team</Text>
          {teamMembers.map((member, index) => (
            <LinearGradient
              key={index}
              colors={[COLORS.cardBg, COLORS.cardBgLight]}
              style={styles.teamCard}
            >
              <LinearGradient
                colors={[member.color, member.color + 'CC']}
                style={styles.teamAvatar}
              >
                <Ionicons name={member.icon} size={28} color={COLORS.white} />
              </LinearGradient>
              <View style={styles.teamInfo}>
                <Text style={styles.teamName}>{member.name}</Text>
                <Text style={styles.teamRole}>{member.role}</Text>
              </View>
              <TouchableOpacity style={styles.teamContact}>
                <Ionicons name="chatbubble-ellipses" size={20} color={COLORS.primary} />
              </TouchableOpacity>
            </LinearGradient>
          ))}
        </View>

        {/* Enhanced Stats Section */}
        <View style={styles.section}>
          <LinearGradient
            colors={[COLORS.primary, COLORS.secondary]}
            style={styles.statsCard}
          >
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>2025</Text>
              <Text style={styles.statLabel}>Founded</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>50+</Text>
              <Text style={styles.statLabel}>Destinations</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>10K+</Text>
              <Text style={styles.statLabel}>Travelers</Text>
            </View>
          </LinearGradient>
        </View>

        {/* Enhanced Contact Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Get In Touch</Text>
          <LinearGradient
            colors={[COLORS.cardBg, COLORS.cardBgLight]}
            style={styles.contactCard}
          >
            <TouchableOpacity
              style={styles.contactItem}
              onPress={() => handleSocialPress('email')}
            >
              <LinearGradient
                colors={[COLORS.accent, COLORS.accentLight]}
                style={styles.contactIcon}
              >
                <Ionicons name="mail" size={20} color={COLORS.white} />
              </LinearGradient>
              <View style={styles.contactInfo}>
                <Text style={styles.contactLabel}>Email Us</Text>
                <Text style={styles.contactText}>hello@spacetravel.app</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
            </TouchableOpacity>
            
            <View style={styles.contactDivider} />
            
            <TouchableOpacity
              style={styles.contactItem}
              onPress={() => handleSocialPress('website')}
            >
              <LinearGradient
                colors={[COLORS.primary, COLORS.primaryLight]}
                style={styles.contactIcon}
              >
                <Ionicons name="globe" size={20} color={COLORS.white} />
              </LinearGradient>
              <View style={styles.contactInfo}>
                <Text style={styles.contactLabel}>Visit Website</Text>
                <Text style={styles.contactText}>www.spacetravel.app</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </LinearGradient>
        </View>

        {/* Enhanced Social Media */}
        <View style={styles.socialSection}>
          <Text style={styles.sectionTitle}>Follow Our Journey</Text>
          <View style={styles.socialButtons}>
            {[
              { name: 'logo-twitter', platform: 'twitter', color: COLORS.primary },
              { name: 'logo-instagram', platform: 'instagram', color: COLORS.secondary },
              { name: 'logo-facebook', platform: 'facebook', color: COLORS.accent },
              { name: 'logo-youtube', platform: 'youtube', color: COLORS.error },
            ].map((social, index) => (
              <TouchableOpacity
                key={index}
                style={styles.socialButton}
                onPress={() => handleSocialPress(social.platform)}
              >
                <LinearGradient
                  colors={[social.color, social.color + 'CC']}
                  style={styles.socialGradient}
                >
                  <Ionicons name={social.name} size={24} color={COLORS.white} />
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Enhanced Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            © 2025 Space Travel. All rights reserved.
          </Text>
          <Text style={styles.footerSubtext}>Made with ❤️ for space enthusiasts</Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  heroSection: {
    alignItems: 'center',
    paddingVertical: 50,
    paddingHorizontal: 20,
    position: 'relative',
  },
  logoContainer: {
    marginBottom: 25,
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  logoGradient: {
    width: 140,
    height: 140,
    borderRadius: 70,
    justifyContent: 'center',
    alignItems: 'center',
  },
  glowEffect: {
    position: 'absolute',
    top: '30%',
    width: 200,
    height: 200,
    backgroundColor: COLORS.nebula,
    borderRadius: 100,
    zIndex: -1,
  },
  appName: {
    fontSize: 42,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    textAlign: 'center',
    fontFamily: 'System',
  },
  tagline: {
    fontSize: 18,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
  section: {
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 20,
    fontFamily: 'System',
  },
  missionCard: {
    borderRadius: 24,
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-start',
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  missionIcon: {
    marginRight: 16,
    marginTop: 4,
  },
  missionText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    lineHeight: 24,
    flex: 1,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    width: '48%',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  featureIcon: {
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    textAlign: 'center',
    fontFamily: 'System',
  },
  featureDescription: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 16,
  },
  teamCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 6,
  },
  teamAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  teamInfo: {
    flex: 1,
  },
  teamName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 4,
    fontFamily: 'System',
  },
  teamRole: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  teamContact: {
    padding: 8,
    backgroundColor: COLORS.primary + '20',
    borderRadius: 12,
  },
  statsCard: {
    flexDirection: 'row',
    borderRadius: 24,
    padding: 30,
    justifyContent: 'space-around',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    fontFamily: 'System',
  },
  statLabel: {
    fontSize: 14,
    color: COLORS.white + 'CC',
    fontWeight: '600',
  },
  statDivider: {
    width: 1,
    backgroundColor: COLORS.white + '40',
  },
  contactCard: {
    borderRadius: 24,
    padding: 0,
    overflow: 'hidden',
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 24,
  },
  contactIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  contactInfo: {
    flex: 1,
  },
  contactLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.white,
    marginBottom: 4,
  },
  contactText: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  contactDivider: {
    height: 1,
    backgroundColor: COLORS.primaryDark,
    marginHorizontal: 24,
  },
  socialSection: {
    paddingHorizontal: 24,
    marginBottom: 40,
    alignItems: 'center',
  },
  socialButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 16,
  },
  socialButton: {
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  socialGradient: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  footerSubtext: {
    fontSize: 12,
    color: COLORS.gray,
  },
});

export default AboutUsScreen;