import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import COLORS from '../utils/colors';
import { destinations } from '../data/destinations';
import { useData } from '../context/DataContext';

const ExploreTripScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('All');
  
  const {
    toggleWishlist,
    addToMyTrips,
    isInWishlist,
    isInMyTrips,
  } = useData();

  const filters = ['All', 'Planets', 'Moons', 'Stations', 'Popular', 'Luxury'];

  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         dest.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'All' || 
      (selectedFilter === 'Popular' ? dest.rating >= 4.7 :
       selectedFilter === 'Luxury' ? dest.price > 200000 :
       dest.category === selectedFilter.toLowerCase().slice(0, -1));
    return matchesSearch && matchesFilter;
  });

  const handleFilterPress = () => {
    // Filter functionality - could be expanded with a modal
    console.log('Filter pressed');
  };

  const handleSortPress = () => {
    // Sort functionality - could be expanded with a modal
    console.log('Sort pressed');
  };

  const navigateToDetails = (destination) => {
    navigation.navigate('DestinationDetails', {
      destination,
      isInWishlist: isInWishlist(destination.id),
      isInMyTrips: isInMyTrips(destination.id),
    });
  };

  return (
    <LinearGradient colors={[COLORS.background, COLORS.gradientMid, COLORS.gradientEnd]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Enhanced Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.headerTitle}>Explore Trips</Text>
            <Text style={styles.headerSubtitle}>Discover cosmic wonders</Text>
          </View>
          <TouchableOpacity style={styles.filterButton} onPress={handleFilterPress}>
            <Ionicons name="filter" size={24} color={COLORS.white} />
          </TouchableOpacity>
        </View>

        {/* Enhanced Search Bar */}
        <View style={styles.searchSection}>
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={20} color={COLORS.textSecondary} style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search destinations, planets, moons..."
              placeholderTextColor={COLORS.textSecondary}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')}>
                <Ionicons name="close-circle" size={20} color={COLORS.textSecondary} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Enhanced Filter Tabs */}
        <View style={styles.filterSection}>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.filterContainer}
          >
            {filters.map((filter) => (
              <TouchableOpacity
                key={filter}
                style={[
                  styles.filterTab,
                  selectedFilter === filter && styles.filterTabActive,
                ]}
                onPress={() => setSelectedFilter(filter)}
              >
                <LinearGradient
                  colors={selectedFilter === filter ? 
                    [COLORS.primary, COLORS.secondary] : 
                    [COLORS.cardBg, COLORS.cardBg]
                  }
                  style={styles.filterGradient}
                >
                  <Text
                    style={[
                      styles.filterText,
                      selectedFilter === filter && styles.filterTextActive,
                    ]}
                  >
                    {filter}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Enhanced Results */}
        <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
          <View style={styles.resultsHeader}>
            <Text style={styles.resultCount}>
              {filteredDestinations.length} destinations found
            </Text>
            <TouchableOpacity style={styles.sortButton} onPress={handleSortPress}>
              <Text style={styles.sortText}>Sort by</Text>
              <Ionicons name="chevron-down" size={16} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>

          {filteredDestinations.map((destination) => (
            <TouchableOpacity 
              key={destination.id} 
              style={styles.destinationCard}
              onPress={() => navigateToDetails(destination)}
            >
              <Image source={{ uri: destination.image }} style={styles.cardImage} />
              <LinearGradient
                colors={['transparent', 'rgba(10, 14, 39, 0.95)']}
                style={styles.cardGradient}
              />
              
              <TouchableOpacity 
                style={styles.wishlistButton}
                onPress={(e) => {
                  e.stopPropagation();
                  toggleWishlist(destination);
                }}
              >
                <Ionicons
                  name={isInWishlist(destination.id) ? 'heart' : 'heart-outline'}
                  size={24}
                  color={COLORS.accent}
                />
              </TouchableOpacity>
              
              {destination.isFeatured && (
                <View style={styles.featuredBadge}>
                  <Text style={styles.featuredBadgeText}>FEATURED</Text>
                </View>
              )}
              
              {destination.discount && (
                <View style={styles.discountBadge}>
                  <Text style={styles.discountBadgeText}>{destination.discount}% OFF</Text>
                </View>
              )}

              <View style={styles.cardInfo}>
                <View style={styles.cardHeader}>
                  <View style={styles.categoryBadge}>
                    <Text style={styles.categoryText}>{destination.category}</Text>
                  </View>
                  <View style={styles.ratingContainer}>
                    <Ionicons name="star" size={16} color={COLORS.star} />
                    <Text style={styles.ratingText}>{destination.rating}</Text>
                  </View>
                </View>
                
                <Text style={styles.cardTitle}>{destination.name}</Text>
                <Text style={styles.cardDescription} numberOfLines={2}>
                  {destination.description}
                </Text>
                
                <View style={styles.cardStats}>
                  <View style={styles.statItem}>
                    <Ionicons name="time" size={16} color={COLORS.accent} />
                    <Text style={styles.statText}>{destination.duration}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Ionicons name="rocket" size={16} color={COLORS.accent} />
                    <Text style={styles.statText}>{destination.distance}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Ionicons name="people" size={16} color={COLORS.accent} />
                    <Text style={styles.statText}>{destination.capacity} seats</Text>
                  </View>
                </View>
                
                <View style={styles.cardFooter}>
                  <View style={styles.priceContainer}>
                    <Text style={styles.priceLabel}>From</Text>
                    <Text style={styles.priceValue}>
                      ${(destination.price / 1000).toFixed(0)}K
                    </Text>
                    {destination.discount && (
                      <Text style={styles.originalPrice}>
                        ${((destination.price * 100) / (100 - destination.discount) / 1000).toFixed(0)}K
                      </Text>
                    )}
                  </View>
                  
                  <TouchableOpacity 
                    style={[
                      styles.bookButton,
                      isInMyTrips(destination.id) && styles.bookButtonBooked
                    ]}
                    onPress={(e) => {
                      e.stopPropagation();
                      if (!isInMyTrips(destination.id)) {
                        addToMyTrips(destination);
                      }
                    }}
                  >
                    <Ionicons 
                      name={isInMyTrips(destination.id) ? "checkmark" : "rocket"} 
                      size={18} 
                      color={COLORS.white} 
                    />
                    <Text style={styles.bookButtonText}>
                      {isInMyTrips(destination.id) ? 'Booked' : 'Book Now'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.white,
    fontFamily: 'System',
  },
  headerSubtitle: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  filterButton: {
    backgroundColor: COLORS.primary,
    padding: 12,
    borderRadius: 12,
  },
  searchSection: {
    paddingHorizontal: 24,
    marginBottom: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.cardBg,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    color: COLORS.white,
    fontSize: 16,
    paddingVertical: 4,
  },
  filterSection: {
    marginBottom: 24,
  },
  filterContainer: {
    paddingHorizontal: 24,
  },
  filterTab: {
    marginRight: 12,
    borderRadius: 20,
    overflow: 'hidden',
  },
  filterGradient: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  filterTabActive: {
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  filterText: {
    color: COLORS.textSecondary,
    fontSize: 14,
    fontWeight: '600',
  },
  filterTextActive: {
    color: COLORS.white,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  resultCount: {
    color: COLORS.textSecondary,
    fontSize: 14,
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.cardBg,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },
  sortText: {
    color: COLORS.textSecondary,
    fontSize: 14,
    marginRight: 4,
  },
  destinationCard: {
    height: 280,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 20,
    shadowColor: COLORS.glow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '70%',
  },
  wishlistButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: 'rgba(30, 41, 59, 0.9)',
    padding: 10,
    borderRadius: 20,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  featuredBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: COLORS.accent,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  featuredBadgeText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: 'bold',
  },
  discountBadge: {
    position: 'absolute',
    top: 50,
    left: 16,
    backgroundColor: COLORS.success,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  discountBadgeText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: 'bold',
  },
  cardInfo: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryBadge: {
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  categoryText: {
    color: COLORS.primaryLight,
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: 'bold',
    marginLeft: 4,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.white,
    marginBottom: 8,
    fontFamily: 'System',
  },
  cardDescription: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 12,
    lineHeight: 20,
  },
  cardStats: {
    flexDirection: 'row',
    marginBottom: 16,
    gap: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginLeft: 6,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  priceLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginRight: 4,
  },
  priceValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.accent,
    marginRight: 8,
    fontFamily: 'System',
  },
  originalPrice: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textDecorationLine: 'line-through',
  },
  bookButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  bookButtonBooked: {
    backgroundColor: COLORS.success,
  },
  bookButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 6,
  },
});

export default ExploreTripScreen;